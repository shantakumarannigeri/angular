import { Component, OnInit } from '@angular/core';
import { IEmployee } from './employee';
import { IBook } from '../book/book';
import { BookService } from '../book.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  
  books:IBook[];
  isUpdate:boolean=false;
  isAdd:boolean=false;
  id:number;
  name:string;
  price:number;
  category:string;
  constructor(private service :BookService) { }

  ngOnInit() {
    this.service.getBook().subscribe(data=> this.books=data);
  }
  delete(book:IBook){
    this.books=this.books.filter(p=>p.id!=book.id);

  }

}
