import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { IBook } from './book';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {

  books:IBook[];
  isUpdate:boolean=false;
  isAdd:boolean=false;
  id:number;
  name:string;
  price:number;
  category:string;
  constructor(private service :BookService) { }

  ngOnInit() {
    this.service.getBook().subscribe(data=> this.books=data);
  }
  
  delete(book:IBook){
    this.books=this.books.filter(p=>p.id!=book.id);

  }
  onSearch(book:IBook){

    let arr= this.books.filter(p=>p.name==book.name);
    
    this.books=arr;
    
     }

  

}
