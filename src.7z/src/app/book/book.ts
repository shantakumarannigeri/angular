export interface IBook
{
    id: number,
    name:string,
    price: number,
    category:string
}