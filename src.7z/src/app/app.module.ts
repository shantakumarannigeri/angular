import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';

import { AppComponent } from './app.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { EmployeeComponent } from './employee/employee.component';
import { Route,RouterModule } from '../../node_modules/@angular/router';
import { BookComponent } from './book/book.component';
import {HttpClientModule} from '@angular/common/http';
import { UserComponent } from './user/user.component';
import { BookformComponent } from './bookform/bookform.component';



const routes: Route []=[
 
  {
    path:'search',
    component:BookComponent
   }, 
   {
  path : 'product',
  component: EmployeeComponent
},
{
 path: '',
 redirectTo:'search',
 pathMatch:'full'
}];
@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    BookComponent,
    UserComponent,
    BookformComponent,

  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
