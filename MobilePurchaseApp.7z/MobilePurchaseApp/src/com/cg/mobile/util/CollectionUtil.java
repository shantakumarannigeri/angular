package com.cg.mobile.util;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;

import com.cg.mobile.entity.Customer;
import com.cg.mobile.entity.Mobile;

public class CollectionUtil {
	private static HashMap<Integer,Mobile> MobMap= new HashMap<Integer,Mobile>();
	static 
	{
		MobMap.put(1, new Mobile(1,11,"Nokia",25000));
		MobMap.put(2, new Mobile(2,22,"Samsung",26000));
		MobMap.put(3, new Mobile(3,33,"Apple",27000));
		MobMap.put(4, new Mobile(4,44,"oneplus",25400));
	}
	private static HashMap<Integer,Customer> CusMap= new HashMap<Integer,Customer>();
	static 
	{
		CusMap.put(1144, new Customer("Nikhil","Bellary",72021));
		CusMap.put(1155, new Customer("Shiva","Banglore",72022));
		CusMap.put(1111, new Customer("Ram","London",72023));
		CusMap.put(1122, new Customer("Ravi","Denmark",720254));
	}
public static int purchaseMobile(Customer c,Mobile m)
{
	MobMap.put(m.getOrderId(),m);
	CusMap.put(m.getOrderId(),c);
	return (int) m.getOrderId();
	
}
public static Mobile getpurchaseDetails(int Orderid) {
	Mobile m=MobMap.get(Orderid);
	return m;
}


}
