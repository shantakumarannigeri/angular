package com.cg.mobile.dao;

import java.util.HashMap;

import com.cg.mobile.entity.Customer;
import com.cg.mobile.entity.Mobile;
import com.cg.mobile.util.CollectionUtil;

public class MobileDAOImpl implements MobileDAO {

	@Override
	public int purchaseMobile(Customer c, Mobile m) {
		// TODO Auto-generated method stub
		int c1=CollectionUtil.purchaseMobile(c, m);
		return c1;
	
	}

	@Override
	public HashMap<Integer, Mobile> MobileDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HashMap<Integer, Customer> CustomerDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Mobile getPurchasedetails(int OrderId) {
		// TODO Auto-generated method stub
	Mobile m3=CollectionUtil.getpurchaseDetails(OrderId);
		return m3;
	}

}
