package com.cg.mobile.dao;

import java.util.HashMap;

import com.cg.mobile.entity.Customer;
import com.cg.mobile.entity.Mobile;

public interface MobileDAO {
	public int purchaseMobile(Customer C,Mobile m);
	public HashMap<Integer,Mobile>MobileDetails();//To add mobile details
	public HashMap<Integer,Customer> CustomerDetails();//to add customer details
	Mobile getPurchasedetails(int OrderId);
}