package com.cg.mobile.ui;

import java.util.Scanner;

import com.cg.mobile.entity.Customer;
import com.cg.mobile.entity.Mobile;
import com.cg.mobile.exception.CustomerException;
import com.cg.mobile.service.MobileService;
import com.cg.mobile.service.MobileServiceImpl;

public class MobRunMain {
static Scanner sc=null;
static MobileService cs=null;
	public static void main(String[] args) {
	 sc = new Scanner(System.in);
		cs= new MobileServiceImpl();
		int choice=0;
		while (true) {
			System.out.println("Welcome for Mobile purchasing app \nPlace an order for mobile");
			System.out.println("Mobiles available for purchase \n(a)Nokia \t(b)Samsung \t(c)Motorola \t(d)Sony");
			System.out.println("1.Purchase Mobile\t2.Order details\n");
			System.out.println("3.mobile details\t4.Customer details");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				try {
					purchaseMobile();
				} catch (CustomerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 2:
				getPurchasedetails();
				break;
			case 3:
				
				default:
					System.out.println("try again");
	}
		}
	}
	private static void getPurchasedetails() {
		System.out.println("Enter OrderId");
		int oid=sc.nextInt();
		Mobile m1=cs.getPurchasedetails(oid);
		System.out.println("order details:"+m1);
		
	}

	private static void purchaseMobile() throws CustomerException{
			System.out.println("Enter customer name:");
			String cname=sc.next();
			System.out.println("Enter the customer address:");
			String cadd=sc.next();
			System.out.println("Enter the customer cell number");
			int ccell=sc.nextInt();
			Customer c=new Customer(cname,cadd,ccell);
			System.out.println("enter mobile model:");
			String mm=sc.next();
			System.out.println("Enter GSTprice and Mobile price");
			int totalpriceGST=sc.nextInt();
			int max=5000;
			int min=1;
			int range=max - min + 1;
			int oid =  (int)(Math.random() * range)+ min;
			int min1=1;
			int max1=25000;
			int range1= max1 - min1 + 1;
			int cid=(int)(Math.random()*range1) + min1;
			Mobile m=new Mobile(oid,cid,mm,totalpriceGST);
			int CustomerDetails=cs.purchaseMobile(c,m);
			System.out.println("Purchased Mobile:"+mm+"and order id is:"+oid);
			System.out.println("Order id:"+CustomerDetails);
		
	}
}

	
