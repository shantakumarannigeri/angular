package com.cg.mobile.service;

import com.cg.mobile.dao.MobileDAO;
import com.cg.mobile.dao.MobileDAOImpl;
import com.cg.mobile.entity.Customer;
import com.cg.mobile.entity.Mobile;

public class MobileServiceImpl implements MobileService{
MobileDAO cd=new MobileDAOImpl();

	@Override
	public int purchaseMobile(Customer c, Mobile m) {
		// TODO Auto-generated method stub
		int c1=cd.purchaseMobile(c,m);
		return c1;
	}

	@Override
	public Mobile getPurchasedetails(int oid) {
		// TODO Auto-generated method stub
		Mobile m2=cd.getPurchasedetails(oid);
		return m2;
	}

}
