package com.cg.mobile.service;

import com.cg.mobile.entity.Customer;
import com.cg.mobile.entity.Mobile;

public interface MobileService {
public int purchaseMobile(Customer C,Mobile m);
public Mobile getPurchasedetails(int oid);


}
