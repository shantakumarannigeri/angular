package com.cg.mobile.entity;

public class Customer {
private String CustomerName;
private String Address;
private double CellNumber;
public Customer() {
	super();
	// TODO Auto-generated constructor stub
}
public Customer(String customerName, String address, int cellNumber) {
	super();
	CustomerName = customerName;
	Address = address;
	CellNumber = cellNumber;
}
@Override
public String toString() {
	return "Customer [CustomerName=" + CustomerName + ", Address=" + Address + ", CellNumber=" + CellNumber + "]";
}

}
