package com.cg.mobile.entity;

public class Mobile {
public double OrderId;
private String CustomerId;
private String modelname;
private int totalpriceGST;
public Mobile() {
	super();
	// TODO Auto-generated constructor stub
}
public Mobile(int orderId, int CustomerId, String modelname, int totalpriceGST) {
	super();
	OrderId = orderId;
	CustomerId = CustomerId;
	this.modelname = modelname;
	this.totalpriceGST = totalpriceGST;
	
	
}

public int getOrderId() {
	return (int) OrderId;
}
public void setOrderId(double orderId) {
	OrderId = orderId;
}
public String getCustomerId() {
	return CustomerId;
}
public void setCustomerId(String customerId) {
	CustomerId = customerId;
}
public double getGSTprice() {
	return totalpriceGST;
}
public void setGSTprice(int gSTprice) {
	totalpriceGST = gSTprice;
}
public String getModelname() {
	return modelname;
}
public void setModelname(String modelname) {
	this.modelname = modelname;
}
public int getTotalpriceGST() {
	return totalpriceGST;
}
public void setTotalpriceGST(int totalpriceGST) {
	this.totalpriceGST = totalpriceGST;
}
@Override
public String toString() {
	return "Mobile [OrderId=" + OrderId + ", CustomerId=" + CustomerId + ", GSTprice=" + totalpriceGST + ", modelname="
			+ modelname + ", totalpriceGST=" + totalpriceGST + "]";
}
}
