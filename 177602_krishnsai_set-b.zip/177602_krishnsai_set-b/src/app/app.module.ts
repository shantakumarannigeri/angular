import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Route,RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { GameComponent } from './game/game.component';
import {HttpClientModule} from '@angular/common/http';
import { ServiceService } from './service.service';



@NgModule({
  declarations: [
    AppComponent,
    GameComponent,
  
  ],
  imports: [
    BrowserModule,RouterModule, HttpClientModule,RouterModule.forRoot([
     { path:'game',
      component:GameComponent
    }
    ]),
    HttpClientModule
  ],
  providers: [ServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
