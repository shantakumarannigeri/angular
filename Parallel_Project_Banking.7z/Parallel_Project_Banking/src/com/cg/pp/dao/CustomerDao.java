package com.cg.pp.dao;

import java.util.HashMap;

import com.cg.pp.entity.Account;
import com.cg.pp.entity.Customer;

public interface CustomerDao {

	
	abstract HashMap<Integer, Account> showBalance(int accid);

	abstract HashMap<Integer, Customer> validateMob(String mobno);

	abstract void addCustomer(int cusid, Account account);
}
