package com.cg.pp.dao;

import java.util.HashMap;

import com.cg.pp.collectionutil.CollectionUtil;
import com.cg.pp.entity.Account;
import com.cg.pp.entity.Customer;

public class CustomerDaoImpl implements CustomerDao {

	
	CollectionUtil cu = new CollectionUtil();
	
	@Override
	public HashMap<Integer, Account> showBalance(int accid) {
		 HashMap<Integer, Account> w =cu.showBalance(accid);
		return w;
	}

	@Override
	public HashMap<Integer, Customer> validateMob(String mobno) {
		 HashMap<Integer, Customer>hm =cu.validateMob(mobno);
		return hm;
	}

	@Override
	public void addCustomer(int cusid, Account account) {
		cu.addCustomer (cusid, account);
		
	}

}
