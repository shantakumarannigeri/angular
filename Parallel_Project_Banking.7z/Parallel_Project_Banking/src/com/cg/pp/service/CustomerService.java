package com.cg.pp.service;

import java.util.HashMap;

import com.cg.pp.entity.Account;
import com.cg.pp.entity.Customer;
import com.cg.pp.exception.CustomerException;

public interface CustomerService 
{
	
	default boolean validateCustomerName(String cusname)  throws CustomerException
	{
		return false;
	}
	default boolean validateCustomerMobileNo(String customerMobileNo) throws CustomerException
	{
		return false;
	}
	default boolean validateCustomerAddress(String customerAddress) throws CustomerException
	{
		return false;
	}
	abstract HashMap<Integer, Account> showBalance(int accid);
	HashMap<Integer, Customer> validateMob(String mobno);
	boolean validateAcctype(String acctype) throws CustomerException;
	int addCustomer(int cusid,Account account);	
}
 